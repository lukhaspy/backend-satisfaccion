<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Satisfaccion extends Model
{
    protected $table = 'satisfaccion';
    protected $guarded = ['id'];
    public $timestamps = false;
}
